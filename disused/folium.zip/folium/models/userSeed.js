let adminSeed = [
  {
    username: "Admin",
    password: "password",
    class: "admin"
  },
  {
    username: "Andi",
    password: "gatekeeper",
    class: "admin"
  }
];

module.exports = adminSeed;
