module.exports = [
  {
    username: 'bill',
    password: 'steve'
  },
  {
    username: 'mogli',
    password: 'jungle'
  },
  {
    username: 'andrea',
    password: 'croak'
  },
  {
    username: 'austyn',
    password: 'heinlein'
  },
  {
    username: 'joseph',
    password: 'weber'
  }
]
